﻿using System;
using static System.Console;
using static ClassLibrary.HelperMethods;


namespace ClassLibrary
{
    public class Player
    {
        public Player()
        {
            this.Stardust = 0;
            this.BankAccount = 1500;
            this.UserFood = 0;
        }
        
        public int BankAccount { get; set; }
        public int Stardust { get; set; }
        public int UserFood { get; set; }


        public void Market(int foodAndWater)
        {
            TypeWriter($"\nWelcome to the Market. What can I help you with today?\n\nYou have ${BankAccount} and {Stardust} stardust");
            TypeWriter($"\n\nEnter 1 to pick up some food and water, \nEnter 2 to sell some stardust, \nEnter 3 to exit!");
            int userInput = Convert.ToInt32(ReadLine());

            while (userInput != 1 && userInput != 2 && userInput != 3)
            {
                Clear();
                TypeWriter("Try again");
                userInput = Convert.ToInt32(ReadLine());
            }
            if (userInput == 1)
            {
                if (BankAccount <= 0) { TypeWriter("\nYou dont have enough money!\n\nPRESS ENTER"); }
                else
                {
                    ManageBankAccount(-foodAndWater);
                    ManageUserFood(foodAndWater);
                    Write($"\nYou have {UserFood} food and water\nPRESS ENTER TO RETURN TO THE HOME PAGE");
                    ReadLine();
                    Clear();
                    Market(foodAndWater);
                }
            }
            else if (userInput == 2)
            {
                if (Stardust <= 0) { TypeWriter("You dont have any Stardust!\n\nPRESS ENTER"); ReadLine(); }
                ManageBankAccount(Stardust * 2);
                Stardust = 0;
                TypeWriter($"\nYou currently have {Stardust} stardust and ${BankAccount}\nPRESS ENTER TO RETURN TO THE HOME PAGE"); ReadLine();
                Clear();
                Market(foodAndWater);
            }
            Clear();
        }

        public void BuyFuel(int fuel)
        {

            TypeWriter($"Welcome to the fuel station! \n \nChoose one of the following options with your ${BankAccount} \n1. Pay $100 to fill up. \n2. I don't need gas. ");
            int userInput = int.Parse(ReadLine());

            while (userInput != 1 && userInput != 2)
            {
                Clear();
                TypeWriter("\nYou havent chosen either option! Try again.");
                userInput = int.Parse(ReadLine());
            }

            if (userInput == 1)
            {
                if (BankAccount < fuel) TypeWriter("\nYou dont have enough money. Try to go sell some stardust.");
                ManageBankAccount(fuel);
                TypeWriter($"\nYou have filled up your tank and you have ${BankAccount} left!");
                ReadLine();
            }
            else{ }
            Clear();
        }

        public void ManageBankAccount( int value)
        {
            BankAccount += value; 
        }

        public void ManageStarDust(int value)
        {
            Stardust += value;
        }

        public void ManageUserFood(int value)
        {
            UserFood += value;
        }

        public void BuyShipAndSuit()
        {
            TypeWriter("enter the square root of 225 to find it!");
            int choice = int.Parse(ReadLine());
            while (choice != 15)
            {
                TypeWriter("Wrong answer, try again.");
                choice = int.Parse(ReadLine());
            }
            Clear();

            TypeWriter($"\nYou have found a spaceship and a space suit!!! You have ${BankAccount}. Would you like to spend $1300? \n Press 1 for yes.\n Press 2 for no. ");
            int userInput = int.Parse(ReadLine());

            while (userInput != 1 && userInput != 2)
            {
                Clear();
                TypeWriter("\nYou havent chosen either option! Try again.");
                userInput = int.Parse(ReadLine());
            }
            if (userInput == 1)
            {
                ManageBankAccount(-1300);
                TypeWriter($"\nCongrats! you are now ready to travel and you have ${BankAccount} left!");
                
            }
            if (userInput == 2)
            {
                TypeWriter($"\nOH NO!!!!! You didn't leave earth in time and died!");
                ReadLine();
                Environment.Exit(0);
            }

            TypeWriter("\nNow that you have a ship, lets get some fuel!\n\nPRESS ENTER");
            ReadLine();
            Clear();

        }

        public void BuyHouse()
        {
            TypeWriter($"Choose a house to move into!\nYou have ${BankAccount}");
            TypeWriter("\nPress 1 to buy this one for $600");
            WriteLine(@"

         _
      _-'_'-_
   _-' _____ '-_
_-' ___________ '-_
 |___|||||||||___|
 |___|||||||||___|
 |___|||||||o|___|
 |___|||||||||___|
 |___|||||||||___|
 |___|||||||||___|

");
            ReadLine();
            TypeWriter("\nPress 2 to buy this one for $1000");
            WriteLine(@"

     _|=|__________
    /              \
   /                \
  /__________________\
   ||  || /--\ ||  ||
   ||[]|| | .| ||[]||
 ()||__||_|__|_||__||()
( )|-|-|-|====|-|-|-|( ) 
^^^^^^^^^^====^^^^^^^^^^^");
            ReadLine();
            TypeWriter("\nPress 3 to buy this one for $1750");
            WriteLine(@"
                      
                                      /\
                                      /\
                                      /\
                                    _`=='_
                                 _-~......~-_
                             _--~............~--_
                       __--~~....................~~--__
           .___..---~~~................................~~~---..___,
            `=.________________________________________________,='
               @^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^@
                        |  |  I   I   II   I   I  |  |
                        |  |__I___I___II___I___I__|  |
                        | /___I_  I   II   I  _I___\ |
                        |'_     ~~~~~~~~~~~~~~     _`|
                    __-~...~~~~~--------------~~~~~...~-__
            ___---~~......................................~~---___
.___..---~~~......................................................~~~---..___,
 `=.______________________________________________________________________,='
    @^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^@
              |   |    | |    |  |    ||    |  |    | |    |   |
              |   |____| |____|  |    ||    |  |____| |____|   |
              |__________________|____||____|__________________|
            _-|_____|_____|_____|__|------|__|_____|_____|_____|-_ 
");
            TypeWriter("\n\nPress 4 if you dont have enough money");
            int userInput = int.Parse(ReadLine());

            if (userInput == 1 && BankAccount >= 600)
            {
                Clear();
                TypeWriter("Congrats on your new house and goodluck!");
                WriteLine(@"

         _
      _-'_'-_
   _-' _____ '-_
_-' ___________ '-_
 |___|||||||||___|
 |___|||||||||___|
 |___|||||||o|___|
 |___|||||||||___|
 |___|||||||||___|
 |___|||||||||___|

");
                ReadLine();
            }

            else if (userInput == 2 && BankAccount >= 1000)
            {
                Clear();
                TypeWriter("Congrats on your new house and goodluck!");
                WriteLine(@"

     _|=|__________
    /              \
   /                \
  /__________________\
   ||  || /--\ ||  ||
   ||[]|| | .| ||[]||
 ()||__||_|__|_||__||()
( )|-|-|-|====|-|-|-|( ) 
^^^^^^^^^^====^^^^^^^^^^^");
                ReadLine();
            }

            else if (userInput == 3 && BankAccount >= 1750)
            {
                Clear();
                TypeWriter("Congrats on your new house and goodluck!");
                WriteLine(@"
                      
                                      /\
                                      /\
                                      /\
                                    _`=='_
                                 _-~......~-_
                             _--~............~--_
                       __--~~....................~~--__
           .___..---~~~................................~~~---..___,
            `=.________________________________________________,='
               @^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^@
                        |  |  I   I   II   I   I  |  |
                        |  |__I___I___II___I___I__|  |
                        | /___I_  I   II   I  _I___\ |
                        |'_     ~~~~~~~~~~~~~~     _`|
                    __-~...~~~~~--------------~~~~~...~-__
            ___---~~......................................~~---___
.___..---~~~......................................................~~~---..___,
 `=.______________________________________________________________________,='
    @^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^@
              |   |    | |    |  |    ||    |  |    | |    |   |
              |   |____| |____|  |    ||    |  |____| |____|   |
              |__________________|____||____|__________________|
            _-|_____|_____|_____|__|------|__|_____|_____|_____|-_ 
");
                ReadLine();
            }

            else
            {
                Clear();
                TypeWriter("You didn't have enough money for a home and froze to death");
                ReadLine();
                Environment.Exit(0);
            }
            Clear();
            TypeWriter("\n\n\nThank you for playing");
            ReadLine();
        }
    }
}