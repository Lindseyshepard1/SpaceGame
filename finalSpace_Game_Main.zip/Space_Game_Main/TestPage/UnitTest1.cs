﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using static System.Console;

namespace TestPage
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {

        }
    }
}
