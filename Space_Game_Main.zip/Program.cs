﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;
using ClassLibrary;
using static ClassLibrary.HelperMethods;

namespace Space_Game_Main
{
    public class Program
    {
        static void Main(string[] args)
        {
            ChangeColor();

            Player player = new Player();
            Planets planets = new Planets();

            planets.Earth(player);
            player.Market(100);


        }
    }
}
